// src/components/Dashboard/Dashboard.jsx
import React from 'react';

const Dashboard = () => {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-blue-600">Đây là trang Thống kê (Admin)</h1>
      <p>Nơi chủ quán xem doanh thu.</p>
    </div>
  );
};

export default Dashboard;