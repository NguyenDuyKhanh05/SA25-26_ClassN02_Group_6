import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import AdminLayout from './components/Layout/AdminLayout';
import Dashboard from './components/Dashboard/Dashboard';
import POSPage from './components/POS/POSPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Đường dẫn mặc định: Vào thẳng Admin */}
        <Route path="/" element={<Navigate to="/admin" replace />} />

        {/* KHU VỰC ADMIN (Có Sidebar) */}
        <Route path="/admin" element={<AdminLayout />}>
          <Route index element={<Dashboard />} />
          {/* Sau này thêm route Kho, Nhân viên vào đây */}
        </Route>

        {/* KHU VỰC POS (Full màn hình, không Sidebar) */}
        <Route path="/pos" element={<POSPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;