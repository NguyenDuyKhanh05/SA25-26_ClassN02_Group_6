// src/constants/mockData.js

export const CATEGORIES = [
  { id: 'all', name: 'Tất cả' },
  { id: 'cafe', name: 'Cà phê' },
  { id: 'tea', name: 'Trà trái cây' },
  { id: 'cake', name: 'Bánh ngọt' },
];

export const PRODUCTS = [
  {
    id: 1,
    name: 'Cà phê Đen Đá',
    price: 25000,
    category: 'cafe',
    image: 'https://placehold.co/150x150/3e2723/ffffff?text=Black+Coffee',
  },
  {
    id: 2,
    name: 'Bạc Xỉu',
    price: 32000,
    category: 'cafe',
    image: 'https://placehold.co/150x150/5d4037/ffffff?text=Bac+Xiu',
  },
  {
    id: 3,
    name: 'Cà phê Sữa',
    price: 29000,
    category: 'cafe',
    image: 'https://placehold.co/150x150/795548/ffffff?text=Milk+Coffee',
  },
  {
    id: 4,
    name: 'Trà Đào Cam Sả',
    price: 45000,
    category: 'tea',
    image: 'https://placehold.co/150x150/f57c00/ffffff?text=Peach+Tea',
  },
  {
    id: 5,
    name: 'Trà Vải Hoa Hồng',
    price: 45000,
    category: 'tea',
    image: 'https://placehold.co/150x150/e91e63/ffffff?text=Lychee+Tea',
  },
  {
    id: 6,
    name: 'Bánh Tiramisu',
    price: 35000,
    category: 'cake',
    image: 'https://placehold.co/150x150/fff9c4/333333?text=Tiramisu',
  },
  {
    id: 7,
    name: 'Bánh Croissant',
    price: 28000,
    category: 'cake',
    image: 'https://placehold.co/150x150/ffecb3/333333?text=Croissant',
  },
];